<?php

namespace App\Http\Controllers;


/**
 * @OA\Info(
 *     title="API de Juegos",
 *     version="1.0.0",
 *     description="Documentación oficial de la API",
 * )
*    @OA\Serve(url="http://127.0.0.1:8000")

 */

abstract class Controller
{
    //
}
